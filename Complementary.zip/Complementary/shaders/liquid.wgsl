fn waterProjectedUv(worldPosition: vec3f, normal: vec3f) -> vec2f {
	let face = abs(normal);
	if (face.y >= face.x && face.y >= face.z) {
		return worldPosition.xz;
	}
	if (face.x >= face.z) {
		return vec2f(worldPosition.z, worldPosition.y);
	}
	return vec2f(worldPosition.x, worldPosition.y);
}

fn waterWave(uv: vec2f, time: f32) -> f32 {
	let longWave = sin(dot(uv, vec2f(0.62, 0.78)) * 1.55 + time * 1.05);
	let crossWave = sin(dot(uv, vec2f(-0.8, 0.6)) * 2.1 - time * 0.72);
	let fineRipple = sin(uv.x * 4.1 + sin(uv.y * 2.7 + time * 0.8) + time * 1.4);
	return longWave * 0.58 + crossWave * 0.28 + fineRipple * 0.14;
}

fn waterWaveGradient(uv: vec2f, time: f32) -> vec2f {
	let longPhase = dot(uv, vec2f(0.62, 0.78)) * 1.55 + time * 1.05;
	let crossPhase = dot(uv, vec2f(-0.8, 0.6)) * 2.1 - time * 0.72;
	let fineInner = uv.y * 2.7 + time * 0.8;
	let finePhase = uv.x * 4.1 + sin(fineInner) + time * 1.4;
	let longSlope = cos(longPhase) * 0.58 * 1.55;
	let crossSlope = cos(crossPhase) * 0.28 * 2.1;
	let fineSlope = cos(finePhase) * 0.14;
	return vec2f(
		longSlope * 0.62 - crossSlope * 0.8 + fineSlope * 4.1,
		longSlope * 0.78 + crossSlope * 0.6 + fineSlope * cos(fineInner) * 2.7
	);
}

fn waterPerturbedNormal(uv: vec2f, time: f32, waveBoost: f32) -> vec3f {
	let slope = waterWaveGradient(uv, time) * (0.055 + waveBoost * 0.14);
	return normalize(vec3f(-slope.x, 1.0, -slope.y));
}

fn waterFresnel(normal: vec3f, viewDirection: vec3f) -> f32 {
	let viewCosine = clamp(abs(dot(normal, viewDirection)), 0.0, 1.0);
	return 0.02 + 0.98 * pow(1.0 - viewCosine, 5.0);
}

#ifndef BLOXD_STRICT
fn bloxd_liquid_vertex(v: bloxd_VertexIn) -> bloxd_Vertex {
	var result: bloxd_Vertex = bloxd_defaultVertex(v);
	let worldPosition = v.position + vec3f(v.originOffset);
	let uv = waterProjectedUv(worldPosition, normalize(v.normal));
	result.position.y += waterWave(uv, v.time) * 0.055;
	return result;
}
#endif

fn bloxd_liquid_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
	var result: bloxd_Surface = bloxd_defaultSurface(s);
	let worldPosition = s.position + vec3f(s.originOffset);
	let uv = waterProjectedUv(worldPosition, normalize(s.normal));
	let geometricNormal = normalize(s.normal);
	let viewDirection = normalize(s.eyePosition - s.position);
	let viewDistance = length(s.eyePosition - s.position);
	let grazingAngle = 1.0 - abs(dot(geometricNormal, viewDirection));
	let nearBoost = 1.0 - smoothstep(4.0, 16.0, viewDistance);
	let waveBoost = max(nearBoost, smoothstep(0.25, 0.78, grazingAngle));
	let normal = waterPerturbedNormal(uv, s.time, waveBoost);
	let fresnel = waterFresnel(normal, viewDirection);
	let baseLuminance = dot(s.colour, vec3f(0.2126, 0.7152, 0.0722));
	let neutralizedColour = mix(s.colour, vec3f(baseLuminance), 0.2);
	let reflectionTint = vec3f(0.64, 0.83, 0.74);

	result.colour = neutralizedColour * vec3f(0.94, 1.1, 0.96);
	result.colour = mix(result.colour, reflectionTint, fresnel * 0.34);
	result.emission = vec3f(0.0);
#ifdef BLOXD_ALPHA
	result.alpha = s.alpha * 0.7;
#endif
	return result;
}

fn bloxd_liquid_light(surface: bloxd_Surface, light: bloxd_LightIn) -> bloxd_Light {
	var result: bloxd_Light = bloxd_defaultLight(surface, light);
	let worldPosition = light.position + vec3f(light.originOffset);
	let uv = waterProjectedUv(worldPosition, normalize(light.normal));
	let geometricNormal = normalize(light.normal);
	let viewDirection = normalize(light.eyePosition - light.position);
	let viewDistance = length(light.eyePosition - light.position);
	let grazingAngle = 1.0 - abs(dot(geometricNormal, viewDirection));
	let nearBoost = 1.0 - smoothstep(4.0, 16.0, viewDistance);
	let waveBoost = max(nearBoost, smoothstep(0.25, 0.78, grazingAngle));
	let waveNormal = waterPerturbedNormal(uv, light.time, waveBoost);
	let normal = normalize(mix(geometricNormal, waveNormal, clamp(abs(geometricNormal.y), 0.0, 1.0)));
	let fresnel = waterFresnel(normal, viewDirection);
	let sunStrength = clamp(length(light.sunDirection), 0.0, 1.0);
	let sunDirection = light.sunDirection / max(sunStrength, 0.0001);
	let halfDirection = normalize(viewDirection + sunDirection);
	let highlightAlignment = max(dot(normal, halfDirection), 0.0);
	let broadGlint = pow(highlightAlignment, mix(48.0, 24.0, waveBoost)) * sunStrength * (1.0 + waveBoost * 2.2);
	let sharpGlint = pow(highlightAlignment, mix(180.0, 100.0, waveBoost)) * sunStrength * (1.0 + waveBoost * 1.5);
	let fogLuminance = dot(light.fogColour, vec3f(0.2126, 0.7152, 0.0722));
	let reflectedSky = mix(vec3f(fogLuminance), light.fogColour, 0.2);

	result.colour = mix(result.colour, reflectedSky, fresnel * 0.32);
	result.colour += vec3f(0.92, 0.96, 0.94) * broadGlint * 0.16;
	result.colour += vec3f(1.0, 0.98, 0.9) * sharpGlint * 0.55;
	return result;
}
