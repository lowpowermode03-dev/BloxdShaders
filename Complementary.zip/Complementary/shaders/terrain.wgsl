fn bloxd_terrain_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
	var result: bloxd_Surface = bloxd_defaultSurface(s);
	let normal = normalize(s.normal);
	let sunFacing = max(dot(normal, s.sunDirection), 0.0);
	let shadeTint = vec3f(0.78, 0.84, 0.96);
	let sunTint = vec3f(1.08, 1.035, 0.94);
	let faceFill = 0.9 + max(normal.y, 0.0) * 0.1;

	result.colour = s.colour * mix(shadeTint, sunTint, smoothstep(0.0, 0.55, sunFacing)) * faceFill;
	result.emission = vec3f(0.0);
#ifdef BLOXD_ALPHA
	result.alpha = s.alpha;
#endif
	return result;
}

fn bloxd_terrain_light(surface: bloxd_Surface, light: bloxd_LightIn) -> bloxd_Light {
	var result: bloxd_Light = bloxd_defaultLight(surface, light);
	let ambientLevel = max(dot(light.ambient, vec3f(0.2126, 0.7152, 0.0722)), 0.0);
	let directLevel = max(light.directional, 0.0);
	let ambientShadowFloor = mix(0.5, 0.76, smoothstep(0.02, 0.65, ambientLevel));
	let directionalVisibility = smoothstep(0.02, 0.42, directLevel);
	let directionalTint = mix(vec3f(0.7, 0.78, 0.94), vec3f(1.12, 1.055, 0.94), directionalVisibility);
	let softShade = mix(ambientShadowFloor, 1.0, directionalVisibility);

	result.colour = result.colour * directionalTint * softShade;
	return result;
}
