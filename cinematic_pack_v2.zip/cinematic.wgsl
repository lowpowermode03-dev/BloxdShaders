const grade_saturation = 1.14;
const grade_contrast = 0.18;
const haze_density = 0.007;
const haze_strength = 0.6;
const cloud_strength = 0.7;
const cloud_scale = 0.006;
const cloud_speed = vec2f(1.2, 0.7);
const sun_fallback = vec3f(0.42, 0.85, 0.32);
const luma = vec3f(0.299, 0.587, 0.114);

fn hash2(p: vec2f) -> f32 {
    return fract(sin(dot(p, vec2f(127.1, 311.7))) * 43758.5453);
}

fn hash3(p: vec3i) -> f32 {
    var h = u32(p.x) * 374761393u + u32(p.y) * 668265263u + u32(p.z) * 2147483647u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    h = h ^ (h >> 16u);
    return f32(h & 65535u) / 65535.0;
}

fn valueNoise(p: vec2f) -> f32 {
    let cell = floor(p);
    let local = fract(p);
    let u = local * local * (3.0 - 2.0 * local);
    let a = hash2(cell);
    let b = hash2(cell + vec2f(1.0, 0.0));
    let c = hash2(cell + vec2f(0.0, 1.0));
    let d = hash2(cell + vec2f(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

fn fbm(p: vec2f) -> f32 {
    var total = 0.0;
    var amp = 0.5;
    var q = p;
    for (var i = 0; i < 3; i++) {
        total += amp * valueNoise(q);
        q = q * 2.03 + vec2f(17.0, 9.0);
        amp *= 0.5;
    }
    return total;
}

fn getSun(raw: vec3f) -> vec3f {
    if (length(raw) < 0.5) {
        return normalize(sun_fallback);
    }
    return normalize(raw);
}

fn sunPower(sun: vec3f) -> f32 {
    return smoothstep(-0.04, 0.14, sun.y);
}

fn dayAmount(sun: vec3f) -> f32 {
    return mix(0.22, 1.0, smoothstep(-0.14, 0.2, sun.y));
}

fn sunColour(sun: vec3f) -> vec3f {
    let elev = clamp(sun.y, 0.0, 1.0);
    return mix(vec3f(1.0, 0.52, 0.24), vec3f(1.0, 0.93, 0.82), smoothstep(0.04, 0.55, elev));
}

fn skyColour(dir: vec3f, sun: vec3f) -> vec3f {
    let up = clamp(dir.y, 0.0, 1.0);
    var sky = mix(vec3f(0.66, 0.78, 0.92), vec3f(0.18, 0.40, 0.82), pow(up, 0.55));
    sky = sky + sunColour(sun) * (pow(max(dot(dir, sun), 0.0), 8.0) * 0.35);
    return sky * dayAmount(sun);
}

fn cloudLight(world: vec3f, t: f32) -> f32 {
    let n = fbm((world.xz + cloud_speed * t) * cloud_scale);
    return 1.0 - cloud_strength * smoothstep(0.46, 0.60, n);
}

fn waterWarp(p: vec2f, t: f32) -> vec2f {
    let q = p * 0.09 + vec2f(t * 0.05, -t * 0.03);
    return vec2f(valueNoise(q) - 0.5, valueNoise(q + vec2f(31.7, 12.3)) - 0.5) * 9.0;
}

fn waterSlope(p_in: vec2f, t: f32) -> vec2f {
    let p = p_in + waterWarp(p_in, t);
    let amp_mod = 0.55 + 0.9 * valueNoise(p_in * 0.05 + vec2f(5.0, 7.0));
    var slope = vec2f(0.0);
    var freq = 1.37;
    var amp = 0.05;
    for (var i = 0; i < 6; i++) {
        let fi = f32(i);
        let dir = vec2f(cos(fi * 2.39996 + 0.4), sin(fi * 2.39996 + 0.4));
        let phase = dot(dir, p) * freq + t * (1.1 + fi * 0.63) + fi * 1.7;
        slope += dir * (cos(phase) * amp * freq);
        freq *= 1.61;
        amp *= 0.62;
    }
    return slope * amp_mod;
}

fn waterHeight(p_in: vec2f, t: f32) -> f32 {
    let p = p_in + waterWarp(p_in, t);
    let amp_mod = 0.55 + 0.9 * valueNoise(p_in * 0.05 + vec2f(5.0, 7.0));
    var height = 0.0;
    var freq = 1.37;
    var amp = 0.05;
    for (var i = 0; i < 4; i++) {
        let fi = f32(i);
        let dir = vec2f(cos(fi * 2.39996 + 0.4), sin(fi * 2.39996 + 0.4));
        let phase = dot(dir, p) * freq + t * (1.1 + fi * 0.63) + fi * 1.7;
        height += sin(phase) * amp;
        freq *= 1.61;
        amp *= 0.62;
    }
    return height * amp_mod * 0.6;
}

fn lavaLook(world: vec3f, t: f32, ndv: f32) -> vec3f {
    let flow = vec2f(t * 0.12, t * 0.07);
    let warp = vec2f(valueNoise(world.xz * 0.35 + flow), valueNoise(world.xz * 0.35 - flow + vec2f(9.0, 4.0))) - 0.5;
    let n = fbm(world.xz * 0.55 + warp * 2.5 + flow * 0.6);
    let cracks = smoothstep(0.38, 0.62, n);
    let pulse = 0.85 + 0.15 * sin(t * 1.6 + n * 9.0);
    let hot = mix(vec3f(1.0, 0.22, 0.02), vec3f(1.0, 0.82, 0.25), cracks * cracks);
    let crust = vec3f(0.10, 0.025, 0.01);
    return mix(crust, hot, cracks) * pulse * (1.6 + 0.6 * (1.0 - ndv));
}

fn gradeColour(c_in: vec3f) -> vec3f {
    var c = max(c_in, vec3f(0.0));
    let peak = dot(c, luma);
    c = c / (1.0 + max(peak - 0.85, 0.0) * 0.9);
    let k = clamp(c, vec3f(0.0), vec3f(1.0));
    c = mix(c, k * k * (3.0 - 2.0 * k), grade_contrast);
    let mid = dot(c, luma);
    c = mix(vec3f(mid), c, grade_saturation);
    c = c * mix(vec3f(0.93, 1.0, 1.07), vec3f(1.06, 1.0, 0.92), smoothstep(0.18, 0.85, mid));
    return c;
}

#ifndef BLOXD_STRICT
fn bloxd_liquid_vertex(v: bloxd_VertexIn) -> bloxd_Vertex {
    var result = bloxd_defaultVertex(v);
    if (v.normal.y > 0.5) {
        let world = v.position + vec3f(v.originOffset);
        result.position.y = result.position.y + waterHeight(world.xz, v.time);
    }
    return result;
}
#endif

fn bloxd_terrain_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
    var result = bloxd_defaultSurface(s);
    let world = s.position + vec3f(s.originOffset);
    let block = vec3i(floor(s.position - s.normal * 0.5)) + s.originOffset;
    let texel = vec3i(floor((world - s.normal * 0.02) * 16.0));
    let block_var = hash3(block) - 0.5;
    let texel_var = hash3(texel) - 0.5;
    let big = vec2f(world.x + world.y * 0.6, world.z - world.y * 0.4);
    let hue_a = fbm(big * 0.035) - 0.5;
    let hue_b = fbm(big * 0.05 + vec2f(40.0, 11.0)) - 0.5;
    let tint = vec3f(1.0 + hue_a * 0.30 + hue_b * 0.10 + block_var * 0.02, 1.0 + hue_b * 0.12 + block_var * 0.015, 1.0 - hue_a * 0.26 - block_var * 0.015);
    result.colour = s.colour * tint * (1.0 + texel_var * 0.04);
    return result;
}

fn bloxd_liquid_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
    var result = bloxd_defaultSurface(s);
    let sun = getSun(s.sunDirection);
    let sun_amount = sunPower(sun);
    let world = s.position + vec3f(s.originOffset);
    var n = normalize(s.normal);
    if (n.y > 0.5) {
        let slope = waterSlope(world.xz, s.time);
        n = normalize(vec3f(-slope.x, 1.0, -slope.y));
    }
    let v = normalize(s.eyePosition - s.position);
    let ndv = clamp(dot(n, v), 0.0, 1.0);
    let fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
    let is_lava = s.colour.r > 0.3 && s.colour.r > s.colour.b * 1.6 && s.colour.r >= s.colour.g * 0.9;
    if (is_lava) {
        result.colour = vec3f(0.05, 0.01, 0.0);
        result.emission = lavaLook(world, s.time, ndv);
#ifdef BLOXD_ALPHA
        result.alpha = 1.0;
#endif
        return result;
    }
    let refl = reflect(-v, n);
    let sky = skyColour(refl, sun);
    let glint = pow(max(dot(refl, sun), 0.0), 500.0) * 10.0;
    let sheen = pow(max(dot(refl, sun), 0.0), 20.0) * 0.3;
    let tex_tint = s.colour / max(dot(s.colour, luma), 0.05);
    let body = mix(vec3f(0.01, 0.12, 0.20), vec3f(0.06, 0.38, 0.46), ndv) * mix(vec3f(1.0), tex_tint, 0.35);
    result.colour = body;
    result.emission = sky * (fres * 0.9) + sunColour(sun) * ((glint + sheen) * sun_amount * (0.4 + fres));
#ifdef BLOXD_ALPHA
    result.alpha = clamp(mix(0.6, 0.97, fres), 0.0, 1.0);
#endif
    return result;
}

fn bloxd_terrain_light(s: bloxd_Surface, l: bloxd_LightIn) -> bloxd_Light {
    var result = bloxd_defaultLight(s, l);
    let sun = getSun(l.sunDirection);
    let day = dayAmount(sun);
    let sun_col = sunColour(sun);
    let n = normalize(l.normal);
    let world = l.position + vec3f(l.originOffset);
    let to_point = l.position - l.eyePosition;
    let dist = length(to_point);
    let v = to_point / max(dist, 0.001);

    var sky_vis = 1.0;
#ifdef BLOXD_LIGHTING
    sky_vis = clamp(l.skyLight, 0.0, 1.0);
#endif

    let wrap = clamp((dot(n, sun) + 0.65) / 1.65, 0.0, 1.0);
    let sun_light = sun_col * (wrap * 0.95 * sunPower(sun) * cloudLight(world, l.time) * sky_vis);
    let hemi = n.y * 0.5 + 0.5;
    let night_tint = mix(vec3f(0.6, 0.75, 1.3), vec3f(1.0), smoothstep(-0.1, 0.2, sun.y));
    let ambient_light = mix(vec3f(0.55, 0.52, 0.48), vec3f(0.62, 0.72, 0.92), hemi) * night_tint * (1.2 * (0.7 + 0.3 * sky_vis) * day);
    var shade = (sun_light + ambient_light) / 1.25;
    shade = mix(vec3f(1.0), shade, 1.0 - clamp(l.directional, 0.0, 1.0) * 0.3);
    shade = mix(vec3f(1.0), shade, l.fogFactor);

    var colour = l.engineColour * shade + s.emission * l.fogFactor;
#ifdef BLOXD_LIGHTING
    colour += (l.blockLight + l.heldLight) * vec3f(0.55, 0.30, 0.12) * s.colour * 0.35;
#endif

    let sun_dot = max(dot(v, sun), 0.0);
    let horizon = select(vec3f(0.66, 0.78, 0.92), l.fogColour, length(l.fogColour) > 0.05);
    let haze_col = mix(horizon, sun_col, pow(sun_dot, 6.0) * 0.6) * day;
    let haze_amt = (1.0 - exp(-dist * haze_density)) * haze_strength * (1.0 - clamp(v.y, 0.0, 1.0) * 0.4);
    colour = mix(colour, haze_col, haze_amt);
    colour += sun_col * ((pow(sun_dot, 3.0) * 0.12 + pow(sun_dot, 24.0) * 0.45 + pow(sun_dot, 220.0) * 2.0) * (0.35 + haze_amt) * sunPower(sun));

    result.colour = gradeColour(colour);
    return result;
}
