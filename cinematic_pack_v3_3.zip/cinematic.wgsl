const grade_saturation = 1.12;
const grade_contrast = 0.16;
const haze_density = 0.006;
const haze_strength = 0.5;
const cloud_strength = 0.3;
const cloud_scale = 0.006;
const cloud_speed = vec2f(1.2, 0.7);
const ray_strength = 0.4;
const leaf_glow = 0.6;
const bloom_spill = 0.5;
const hot_glow_strength = 0.5;
const underwater_strength = 1.0;
const sun_fallback = vec3f(0.42, 0.85, 0.32);
const luma = vec3f(0.299, 0.587, 0.114);

fn hash2(p: vec2f) -> f32 {
    return fract(sin(dot(p, vec2f(127.1, 311.7))) * 43758.5453);
}

fn hash3(p: vec3i) -> f32 {
    var h = u32(p.x) * 374761393u + u32(p.y) * 668265263u + u32(p.z) * 2147483647u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    h = h ^ (h >> 16u);
    return f32(h & 65535u) / 65535.0;
}

fn valueNoise(p: vec2f) -> f32 {
    let cell = floor(p);
    let local = fract(p);
    let u = local * local * (3.0 - 2.0 * local);
    let a = hash2(cell);
    let b = hash2(cell + vec2f(1.0, 0.0));
    let c = hash2(cell + vec2f(0.0, 1.0));
    let d = hash2(cell + vec2f(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

fn fbm(p: vec2f) -> f32 {
    var total = 0.0;
    var amp = 0.5;
    var q = p;
    for (var i = 0; i < 3; i++) {
        total += amp * valueNoise(q);
        q = q * 2.03 + vec2f(17.0, 9.0);
        amp *= 0.5;
    }
    return total;
}

fn fbmCentered(p: vec2f) -> f32 {
    return fbm(p) / 0.875;
}

fn getSun(raw: vec3f) -> vec3f {
    if (length(raw) < 0.5) {
        return normalize(sun_fallback);
    }
    return normalize(raw);
}

fn sunPower(sun: vec3f) -> f32 {
    return smoothstep(-0.04, 0.14, sun.y);
}

fn dayAmount(sun: vec3f) -> f32 {
    return mix(0.22, 1.0, smoothstep(-0.14, 0.2, sun.y));
}

fn sunColour(sun: vec3f) -> vec3f {
    let elev = clamp(sun.y, 0.0, 1.0);
    return mix(vec3f(1.0, 0.52, 0.24), vec3f(1.0, 0.93, 0.82), smoothstep(0.04, 0.55, elev));
}

fn skyColour(dir: vec3f, sun: vec3f) -> vec3f {
    let up = clamp(dir.y, 0.0, 1.0);
    var sky = mix(vec3f(0.66, 0.78, 0.92), vec3f(0.18, 0.40, 0.82), pow(up, 0.55));
    sky = sky + sunColour(sun) * (pow(max(dot(dir, sun), 0.0), 8.0) * 0.35);
    return sky * dayAmount(sun);
}

fn cloudLight(world: vec3f, t: f32) -> f32 {
    let n = fbm((world.xz + cloud_speed * t) * cloud_scale);
    return 1.0 - cloud_strength * smoothstep(0.46, 0.68, n);
}

fn waterWarp(p: vec2f, t: f32) -> vec2f {
    let q = p * 0.09 + vec2f(t * 0.05, -t * 0.03);
    return vec2f(valueNoise(q) - 0.5, valueNoise(q + vec2f(31.7, 12.3)) - 0.5) * 9.0;
}

fn waterRipples(p: vec2f, t: f32, near: f32) -> vec2f {
    var slope = vec2f(0.0);
    var freq = 7.0;
    var amp = 0.02;
    for (var i = 0; i < 3; i++) {
        let fi = f32(i);
        let dir = vec2f(cos(fi * 2.39996 + 1.9), sin(fi * 2.39996 + 1.9));
        let phase = dot(dir, p) * freq + t * (2.6 + fi * 1.1) + fi * 3.1;
        slope += dir * (cos(phase) * amp * freq);
        freq *= 1.7;
        amp *= 0.6;
    }
    return slope * near;
}

fn waterSlope(p_in: vec2f, t: f32, reach: f32) -> vec2f {
    let p = p_in + waterWarp(p_in, t);
    let amp_mod = 0.55 + 0.9 * valueNoise(p_in * 0.05 + vec2f(5.0, 7.0));
    var slope = vec2f(0.0);
    var freq = 1.37;
    var amp = 0.05;
    for (var i = 0; i < 6; i++) {
        let fi = f32(i);
        let fade = 1.0 - smoothstep(0.6, 3.0, freq * reach);
        let dir = vec2f(cos(fi * 2.39996 + 0.4), sin(fi * 2.39996 + 0.4));
        let phase = dot(dir, p) * freq + t * (1.1 + fi * 0.63) + fi * 1.7;
        slope += dir * (cos(phase) * amp * freq * fade);
        freq *= 1.61;
        amp *= 0.62;
    }
    return slope * amp_mod;
}

fn waterHeight(p_in: vec2f, t: f32) -> f32 {
    let p = p_in + waterWarp(p_in, t);
    let amp_mod = 0.55 + 0.9 * valueNoise(p_in * 0.05 + vec2f(5.0, 7.0));
    var height = 0.0;
    var freq = 1.37;
    var amp = 0.05;
    for (var i = 0; i < 4; i++) {
        let fi = f32(i);
        let dir = vec2f(cos(fi * 2.39996 + 0.4), sin(fi * 2.39996 + 0.4));
        let phase = dot(dir, p) * freq + t * (1.1 + fi * 0.63) + fi * 1.7;
        height += sin(phase) * amp;
        freq *= 1.61;
        amp *= 0.62;
    }
    return height * amp_mod * 0.6;
}

fn lavaLook(p_in: vec2f, t: f32, ndv: f32, dist: f32) -> vec3f {
    let near = 1.0 - smoothstep(12.0, 80.0, dist);
    let flow = vec2f(t * 0.05, t * 0.03);
    let warp = vec2f(valueNoise(p_in * 0.18 + flow), valueNoise(p_in * 0.18 - flow + vec2f(9.0, 4.0))) - 0.5;
    let p = p_in * 0.30 + warp * 4.0 + flow;
    let heat = fbm(p);
    let ridge = 1.0 - smoothstep(0.0, mix(0.22, 0.10, near), abs(heat - 0.45));
    let heat2 = fbm(p * 2.7 + vec2f(5.0, 2.0) - flow * 2.0);
    let ridge2 = (1.0 - smoothstep(0.0, 0.07, abs(heat2 - 0.44))) * near * 0.6;
    let net = clamp(ridge + ridge2, 0.0, 1.0);
    let pulse = 0.85 + 0.15 * sin(t * 1.2 + heat * 10.0);
    let crust = vec3f(0.10, 0.02, 0.008);
    let molten = mix(vec3f(1.0, 0.25, 0.03), vec3f(1.0, 0.8, 0.3), net * net);
    var col = mix(crust, molten, 0.18 + 0.82 * net);
    let far = smoothstep(80.0, 220.0, dist);
    col = mix(col, vec3f(0.7, 0.2, 0.04), far * 0.6);
    return col * pulse * (1.5 + 0.8 * (1.0 - ndv));
}

fn causticLines(p: vec2f, t: f32) -> f32 {
    let a = sin(p.x * 1.7 + t * 1.3 + sin(p.y * 1.3 + t * 0.9) * 1.6);
    let b = sin(p.y * 1.9 - t * 1.1 + sin(p.x * 1.1 - t * 0.7) * 1.8);
    return pow(clamp(1.0 - abs(a * b), 0.0, 1.0), 6.0);
}

fn rayPattern(v: vec3f, sun: vec3f, t: f32) -> f32 {
    var side = cross(vec3f(0.0, 1.0, 0.0), sun);
    if (length(side) < 0.05) {
        side = vec3f(1.0, 0.0, 0.0);
    }
    side = normalize(side);
    let up_axis = cross(sun, side);
    let ang = atan2(dot(v, up_axis), dot(v, side));
    let a = sin(ang * 9.0 + t * 0.03) * 0.5 + sin(ang * 17.0 - t * 0.045 + 1.3) * 0.3 + sin(ang * 31.0 + t * 0.02 + 4.1) * 0.2;
    return smoothstep(0.05, 0.9, a * 0.5 + 0.5);
}

fn gradeColour(c_in: vec3f) -> vec3f {
    var c = max(c_in, vec3f(0.0));
    let peak = dot(c, luma);
    c = c / (1.0 + max(peak - 0.85, 0.0) * 0.9);
    let k = clamp(c, vec3f(0.0), vec3f(1.0));
    c = mix(c, k * k * (3.0 - 2.0 * k), grade_contrast);
    let mid = dot(c, luma);
    c = mix(vec3f(mid), c, grade_saturation);
    c = c * mix(vec3f(1.02, 1.0, 0.98), vec3f(1.04, 1.0, 0.95), smoothstep(0.18, 0.85, mid));
    return c;
}

#ifndef BLOXD_STRICT
fn bloxd_liquid_vertex(v: bloxd_VertexIn) -> bloxd_Vertex {
    var result = bloxd_defaultVertex(v);
    if (v.normal.y > 0.5) {
        let world = v.position + vec3f(v.originOffset);
        result.position.y = result.position.y + waterHeight(world.xz, v.time);
    }
    return result;
}
#endif

fn bloxd_terrain_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
    var result = bloxd_defaultSurface(s);
    let world = s.position + vec3f(s.originOffset);
    let block = vec3i(floor(s.position - s.normal * 0.5)) + s.originOffset;
    // let texel = vec3i(floor((world - s.normal * 0.02) * 16.0));
    let block_var = hash3(block) - 0.5;
    // let texel_var = hash3(texel) - 0.5;
    let big = vec2f(world.x + world.y * 0.6, world.z - world.y * 0.4);
    let hue_a = fbmCentered(big * 0.035) - 0.5;
    let hue_b = fbmCentered(big * 0.05 + vec2f(40.0, 11.0)) - 0.5;
    let tint = vec3f(1.0 + hue_a * 0.22 + hue_b * 0.08 + block_var * 0.02, 1.0 + hue_b * 0.10 + block_var * 0.015, 1.0 - hue_a * 0.20 - block_var * 0.015);
    result.colour = s.colour * tint;

    // let sun = getSun(s.sunDirection);
    // let view_dir = normalize(s.position - s.eyePosition);
    // let toward = pow(max(dot(view_dir, sun), 0.0), 2.5);
    // let leafy = smoothstep(1.08, 1.25, s.colour.g / max(s.colour.r, 0.02)) * smoothstep(1.15, 1.5, s.colour.g / max(s.colour.b, 0.02));
    // result.emission = result.emission + s.colour * vec3f(0.85, 1.0, 0.3) * (toward * leafy * sunPower(sun) * cloudLight(world, s.time) * leaf_glow);
    return result;
}

fn bloxd_liquid_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
    var result = bloxd_defaultSurface(s);
    let sun = getSun(s.sunDirection);
    let sun_amount = sunPower(sun);
    let day = dayAmount(sun);
    let world = s.position + vec3f(s.originOffset);
    let to_eye = s.eyePosition - s.position;
    let dist = length(to_eye);
    let v = to_eye / max(dist, 0.001);
    let reach = dist * 0.004 / max(abs(v.y), 0.2);
    var n = normalize(s.normal);

    let is_lava = s.colour.r > 0.3 && s.colour.r > s.colour.b * 1.6 && s.colour.r >= s.colour.g * 0.9;
    if (is_lava) {
        let ndv_l = clamp(dot(n, v), 0.0, 1.0);
        result.colour = vec3f(0.05, 0.01, 0.0);
        result.emission = lavaLook(select(world.xz, vec2f(world.x + world.z, world.y), abs(n.y) < 0.5), s.time, ndv_l, dist);
#ifdef BLOXD_ALPHA
        result.alpha = 1.0;
#endif
        return result;
    }

    if (n.y > 0.5 && v.y < 0.0) {
        let slope_b = waterSlope(world.xz, s.time, reach) * 0.8;
        let nb = normalize(vec3f(slope_b.x, -1.0, slope_b.y));
        let cos_t = clamp(dot(nb, v), 0.0, 1.0);
        let window = smoothstep(0.60, 0.72, cos_t);
        let h = -vec2f(v.x, v.z) * 1.33;
        let out_dir = vec3f(h.x, sqrt(max(1.0 - dot(h, h), 0.0)), h.y);
        let window_col = skyColour(out_dir, sun) * vec3f(0.55, 0.85, 0.95) + sunColour(sun) * (pow(max(dot(out_dir, sun), 0.0), 64.0) * 2.5 * sun_amount);
        let mirror_col = vec3f(0.02, 0.15, 0.21) * day;
        result.colour = vec3f(0.0);
        result.emission = mix(mirror_col, window_col, window);
#ifdef BLOXD_ALPHA
        result.alpha = 0.92;
#endif
        return result;
    }

    if (abs(n.y) < 0.5) {
        let sp = vec2f(world.x + world.z, world.y);
        let drift = fbm(sp * vec2f(0.45, 0.8) + vec2f(s.time * 0.04, -s.time * 0.03)) / 0.875;
        let streak = causticLines(sp * vec2f(1.1, 0.9), s.time * 0.6) * 0.12;
        let side_body = mix(vec3f(0.015, 0.10, 0.16), vec3f(0.06, 0.32, 0.40), drift) * mix(vec3f(1.0), s.colour / max(dot(s.colour, luma), 0.05), 0.3);
        result.colour = side_body;
        result.emission = skyColour(vec3f(0.0, 0.3, 1.0), sun) * (0.10 + streak) * vec3f(0.5, 0.9, 1.0);
#ifdef BLOXD_ALPHA
        result.alpha = mix(0.62, 0.86, drift);
#endif
        return result;
    }
    let far = smoothstep(30.0, 160.0, dist);
    let near = 1.0 - smoothstep(6.0, 45.0, dist);
    if (n.y > 0.5) {
        let slope = waterSlope(world.xz, s.time, reach);
        n = normalize(vec3f(-slope.x, 1.0, -slope.y));
        n = normalize(mix(n, vec3f(0.0, 1.0, 0.0), far * 0.5));
    }
    let ndv = clamp(dot(n, v), 0.0, 1.0);
    let fres = 0.03 + 0.62 * pow(1.0 - ndv, 4.0);
    var refl = reflect(-v, n);
    refl.y = max(refl.y, 0.03);
    refl = normalize(refl);
    let sky = skyColour(refl, sun);
    let glint_pow = mix(500.0, 60.0, far);
    let glint = pow(max(dot(refl, sun), 0.0), glint_pow) * mix(8.0, 2.5, far);
    let sheen = pow(max(dot(refl, sun), 0.0), 20.0) * 0.25;
    let tex_tint = s.colour / max(dot(s.colour, luma), 0.05);
    let body_near = mix(vec3f(0.02, 0.14, 0.20), vec3f(0.07, 0.40, 0.46), ndv);
    let body = mix(body_near, vec3f(0.22, 0.45, 0.54) * day, far * 0.6) * mix(vec3f(1.0), tex_tint, 0.35);
    let refl_col = mix(sky, body * 1.5, 0.22);
    result.colour = body * (1.0 - fres);
    // let twinkle = smoothstep(0.80, 1.0, valueNoise(world.xz * 8.0 + vec2f(s.time * 1.3, s.time * 0.9))) * pow(max(dot(refl, sun), 0.0), 6.0) * near * 1.6;
    result.emission = refl_col * fres + sunColour(sun) * ((glint + sheen) * sun_amount * (0.4 + fres));
#ifdef BLOXD_ALPHA
    result.alpha = clamp(mix(0.72, 0.96, fres * 1.54), 0.0, 1.0);
#endif
    return result;
}

fn bloxd_terrain_light(s: bloxd_Surface, l: bloxd_LightIn) -> bloxd_Light {
    var result = bloxd_defaultLight(s, l);
    let sun = getSun(l.sunDirection);
    let day = dayAmount(sun);
    let sun_col = sunColour(sun);
    let n = normalize(l.normal);
    let world = l.position + vec3f(l.originOffset);
    let to_point = l.position - l.eyePosition;
    let dist = length(to_point);
    let v = to_point / max(dist, 0.001);

    var sky_vis = 1.0;
#ifdef BLOXD_LIGHTING
    sky_vis = clamp(l.skyLight, 0.0, 1.0);
#endif

    let wrap = clamp((dot(n, sun) + 0.65) / 1.65, 0.0, 1.0);
    let sun_light = sun_col * (wrap * 0.95 * sunPower(sun) * cloudLight(world, l.time) * sky_vis);
    let hemi = n.y * 0.5 + 0.5;
    let night_tint = mix(vec3f(0.6, 0.75, 1.3), vec3f(1.0), smoothstep(-0.1, 0.2, sun.y));
    let ambient_light = mix(vec3f(0.56, 0.52, 0.47), vec3f(0.64, 0.67, 0.74), hemi) * night_tint * (1.2 * (0.6 + 0.4 * sky_vis) * day);
    var shade = (sun_light + ambient_light) / 1.25;
    shade = mix(vec3f(1.0), shade, 1.0 - clamp(l.directional, 0.0, 1.0) * 0.3);
    shade = mix(vec3f(1.0), shade, l.fogFactor);

    var colour = l.engineColour * shade + s.emission * l.fogFactor;
#ifdef BLOXD_LIGHTING
    let bl = vec3f(l.blockLight + l.heldLight);
    let spill = pow(clamp(bl, vec3f(0.0), vec3f(1.0)), vec3f(0.7));
    colour += spill * vec3f(0.55, 0.30, 0.12) * s.colour * bloom_spill;
    let hot = smoothstep(0.85, 0.92, s.colour.r) * smoothstep(0.30, 0.42, s.colour.g) * (1.0 - smoothstep(0.75, 0.85, s.colour.g)) * (1.0 - smoothstep(0.10, 0.22, s.colour.b));
    let hot_glow = hot * smoothstep(0.3, 0.7, max(bl.r, max(bl.g, bl.b)));
    colour += s.colour * (hot_glow * hot_glow_strength) * l.fogFactor;
#endif

    let sun_dot = max(dot(v, sun), 0.0);
    let horizon_raw = select(vec3f(0.66, 0.78, 0.92), l.fogColour, length(l.fogColour) > 0.05);
    let horizon = mix(horizon_raw, vec3f(dot(horizon_raw, luma)), 0.3);
    let haze_col = mix(horizon, sun_col, pow(sun_dot, 6.0) * 0.6) * day;
    let haze_amt = (1.0 - exp(-dist * haze_density)) * haze_strength * (1.0 - clamp(v.y, 0.0, 1.0) * 0.4);
    colour = mix(colour, haze_col, haze_amt);
    colour += sun_col * ((pow(sun_dot, 3.0) * 0.14 + pow(sun_dot, 10.0) * 0.12) * (0.35 + haze_amt) * sunPower(sun));

    let fog_ratio = l.fogColour.b / max(l.fogColour.r, 0.02);
    let uw = smoothstep(1.8, 2.8, fog_ratio) * underwater_strength;

    // let scatter = 1.0 - exp(-dist * 0.015);
    // let shafts = rayPattern(v, sun, l.time) * pow(sun_dot, 3.0) * scatter * ray_strength * (1.0 + uw * 1.5) * sunPower(sun);
    // colour += sun_col * shafts;

    if (uw > 0.001) {
        let absorb = exp(-dist * vec3f(0.16, 0.055, 0.03));
        let deep = vec3f(0.02, 0.16, 0.22) * day;
        var under = colour * absorb + deep * (vec3f(1.0) - absorb);
        let lines = causticLines(world.xz * 1.1, l.time) * clamp(n.y, 0.0, 1.0);
        under += s.colour * lines * 0.5 * absorb * sky_vis;
        colour = mix(colour, under, uw);
    }

    result.colour = gradeColour(colour);
    return result;
}
