const zone_size = 6.0;
const luma = vec3f(0.299, 0.587, 0.114);

fn getZone(p: vec3f, origin_offset: vec3i, use_z: bool) -> i32 {
    let world = p + vec3f(origin_offset);
    var coord = world.x;
    if (use_z) {
        coord = world.z;
    }
    return i32(floor(coord / zone_size)) & 7;
}

#ifndef BLOXD_STRICT
fn bloxd_terrain_vertex(v: bloxd_VertexIn) -> bloxd_Vertex {
    var result = bloxd_defaultVertex(v);
    if (getZone(v.position, v.originOffset, false) == 7 && v.normal.y > 0.5) {
        let world = v.position + vec3f(v.originOffset);
        result.position.y = result.position.y + sin(world.x * 0.8 + world.z * 0.8 + v.time * 2.0) * 0.05;
    }
    return result;
}
#endif

fn bloxd_terrain_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
    var result = bloxd_defaultSurface(s);
    let zone = getZone(s.position, s.originOffset, false);
    let block = vec3i(floor(s.position - s.normal * 0.5)) + s.originOffset;
    if (zone == 1) {
        result.colour = s.normal * 0.5 + vec3f(0.5);
    } else if (zone == 2) {
        result.colour = vec3f(dot(s.colour, luma));
    } else if (zone == 3) {
        if (((block.x + block.y + block.z) & 1) == 0) {
            result.colour = vec3f(1.0, 0.2, 0.2);
        } else {
            result.colour = vec3f(0.2, 0.2, 1.0);
        }
    } else if (zone == 4) {
        let d = clamp(length(s.position - s.eyePosition) / 48.0, 0.0, 1.0);
        result.colour = mix(vec3f(1.0, 0.1, 0.1), vec3f(0.1, 0.1, 1.0), d);
    } else if (zone == 5) {
        if (length(s.sunDirection) < 0.5) {
            result.colour = vec3f(1.0, 0.0, 1.0);
        } else {
            result.colour = vec3f(max(dot(s.normal, s.sunDirection), 0.0));
        }
    } else if (zone == 6) {
        let pulse = 0.5 + 0.5 * sin(s.time * 3.0);
        result.emission = vec3f(1.0, 0.4, 0.1) * pulse;
    } else if (zone == 7) {
#ifdef BLOXD_ALPHA
        result.alpha = 0.5 + 0.5 * sin(s.time * 2.0);
#else
        result.colour = vec3f(1.0, 0.0, 0.0);
#endif
#ifndef BLOXD_STRICT
        if (((block.x + block.z) & 3) == 0) {
            discard;
        }
#endif
    }
    return result;
}

fn bloxd_terrain_light(s: bloxd_Surface, l: bloxd_LightIn) -> bloxd_Light {
    var result = bloxd_defaultLight(s, l);
    let zone = getZone(l.position, l.originOffset, true) & 3;
    if (zone == 1) {
        result.colour = vec3f(l.fogFactor);
    } else if (zone == 2) {
        result.colour = vec3f(l.directional) * 0.5 + l.ambient;
    } else if (zone == 3) {
#ifdef BLOXD_LIGHTING
        result.colour = l.blockLight + vec3f(0.0, 0.0, l.skyLight) + l.heldLight;
#else
        result.colour = vec3f(1.0, 0.0, 1.0);
#endif
    }
    return result;
}

fn bloxd_liquid_surface(s: bloxd_SurfaceIn) -> bloxd_Surface {
    var result = bloxd_defaultSurface(s);
    let world = s.position + vec3f(s.originOffset);
    let wave = 0.5 + 0.5 * sin(world.x * 1.5 + world.z * 1.5 + s.time * 2.0);
    result.colour = mix(vec3f(0.05, 0.3, 0.8), vec3f(0.2, 0.8, 0.9), wave);
#ifdef BLOXD_ALPHA
    result.alpha = 0.65;
#endif
    return result;
}
